import os

import pytest
from seamoor.model import Model


@pytest.fixture()
def model():
    return Model()


@pytest.fixture()
def test_input_dir():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "input"))


def test_init(model):
    assert model is not None
    assert model.system is not None


@pytest.fixture()
def compare_file_to_reference(tmpdir, test_input_dir):
    def f(filename_new):
        path_new = os.path.join(tmpdir, filename_new)
        path_old = os.path.join(test_input_dir, filename_new)
        with open(path_new, "r") as f_new, open(path_old, "r") as f_old:
            for line_new, line_old in zip(f_new, f_old):
                assert line_new == line_old

    return f


@pytest.mark.parametrize("filename", ["current.dat", "waves.dat"])
def test_write_environment(tmpdir, model, filename, compare_file_to_reference):

    model._write_environment(tmpdir)

    assert os.path.exists(os.path.join(tmpdir, filename))
    compare_file_to_reference(filename)


@pytest.mark.parametrize("filename", ["LineName.inp", "sections.dat"])
def test_write_lines(tmpdir, model, filename, compare_file_to_reference):

    model._write_line_files(tmpdir)

    assert os.path.exists(os.path.join(tmpdir, filename))
    compare_file_to_reference(filename)


@pytest.mark.parametrize("filename", ["MOOR.INP"])
def test_write_system(tmpdir, model, filename, compare_file_to_reference):

    model._write_system_file(tmpdir)

    assert os.path.exists(os.path.join(tmpdir, filename))
    compare_file_to_reference(filename)


@pytest.mark.parametrize("filename", ["params.dat"])
def test_write_parameters(tmpdir, model, filename, compare_file_to_reference):

    model._write_numerical_parameters(tmpdir)

    assert os.path.exists(os.path.join(tmpdir, filename))
    compare_file_to_reference(filename)


def test_write_all_files(tmpdir, test_input_dir, model, compare_file_to_reference):
    model.write(tmpdir)

    for filename in os.listdir(test_input_dir):
        assert os.path.exists(os.path.join(tmpdir, filename))
        compare_file_to_reference(filename)


def test_run_pre_statics(tmpdir, model):
    model.run_pre_statics(tmpdir)
    assert os.path.exists(os.path.join(tmpdir, "cgten.out"))
    assert os.path.exists(os.path.join(tmpdir, "MOOR.out"))
