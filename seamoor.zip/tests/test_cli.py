import pytest
from click.testing import CliRunner

from seamoor.cli import cli


@pytest.fixture()
def runner():
    """A CliRunner in an isolated environment."""
    runner = CliRunner()
    with runner.isolated_filesystem():
        yield runner


@pytest.mark.parametrize("command", ["run", "write"])
@pytest.mark.parametrize(
    "option",
    ["--pre-static", "--static", "--harmonic", "--dynamic", "--implicit", "--explicit"],
)
def test_cli(runner, command, option):
    result = runner.invoke(cli, [command, option])
    assert result.exit_code == 0
