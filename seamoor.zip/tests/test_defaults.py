import os

import pytest
import toml
from seamoor.config import Environment, System


@pytest.fixture()
def defaults_dir():
    here = os.path.abspath(os.path.dirname(__file__))
    default_dir = os.path.join(here, "..", "src", "seamoor", "defaults")
    return os.path.abspath(default_dir)


@pytest.fixture()
def toml_loader(defaults_dir):
    def f(filename):
        with open(os.path.join(defaults_dir, filename), "r") as f_obj:
            return toml.load(f_obj)

    return f


def test_section_defaults(toml_loader):
    dict_ = toml_loader("sections.toml")
    assert dict_ is not None


def test_environment_defaults():
    environment = Environment()
    assert environment.wave_amplitude == 0.0
    assert environment.wave_frequency == 0.0
    assert environment.wave_direction == 0.0

    assert environment.current_depth == [0.0, 2000.0]
    assert environment.current_x_velocity == [0.0, 0.0]
    assert environment.current_y_velocity == [0.0, 0.0]
    assert environment.current_z_velocity == [0.0, 0.0]


def test_system_defaults():
    system = System()
    assert system.description == "A brief description of the case"
    assert system.reference_location == [0.0, -36.4, 0.0]
    assert system.initial_displacement == [0.0, 0.0, 0.0]
    assert system.initial_rotation == [0.0, 0.0, 0.0]

    param = system.parameter
    assert param.relaxation == 1.0
    assert param.structural_damping == 4e-3
    assert param.ramping_constant == 0.1
    assert param.beta == 0.25
    assert param.gamma == 0.5
    assert param.tolerance == 1e-3
    assert param.max_iterations == 500
    assert param.start_time == 0.0
    assert param.end_time == 500.0
    assert param.time_step == 0.1
    assert param.water_density == 1.025
    assert param.contents_density == 0.0
    assert param.gravity == 9.81
    assert param.water_depth == 1847.088

    assert system.run.job_number == 0
    assert system.run.job_motion == 1

    assert system.filename.cg_tension == "cgten.out"
    assert system.filename.results == "results.out"


def test_line_defaults():
    system = System()
    line = system.lines[0]

    assert line.name == "LineName"
    assert line.pretension == 8.0e3
    assert line.top_coordinates == [37.4569, -27.809, -33.6652]
    assert line.bottom_coordinates == [1542.48791, -1847.088, -1827.2913]

    segment = line.segments[0]
    assert segment.type_name == "Top-Chain"
    assert segment.length == 128.016
    assert segment.num_elements == 4

    t = segment.section_type
    assert t.name == "Top-Chain"
    assert t.youngs_modulus == 2e8

    r = line.results
    assert r.nodal_output_frequency == 2
    assert r.snapshot_frequency == 100
    assert r.output_nodes == [1]

    assert r.write_displacement
    assert not r.write_slope
    assert not r.write_velocity
    assert not r.write_angular_velocity
    assert r.write_tension
    assert not r.write_bending_moment
    assert not r.write_shear_force
    assert not r.write_current_force


def test_inheritance(tmpdir):
    with open(os.path.join(tmpdir, "environment.toml"), "w") as f:
        dict_ = {"wave": {"amplitude": 10.0}}
        toml.dump(dict_, f)

    environment = Environment(directory=tmpdir)

    assert environment.wave_amplitude == 10.0
    assert environment.wave_frequency == 0.0
