.. _api-index:

=================
API Documentation
=================

The |project| API documentation contains detailed descriptions of the modules within the |project| package.
It is provided as a reference to aid in further development of the software and extension to different problems.
Each public module, class, method, and function are documented within the source code.
As such, this documentation can easily be updated as the code base is modified and extended.

.. contents::
   :depth: 3
