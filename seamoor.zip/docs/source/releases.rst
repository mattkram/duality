.. _development_release_notes:

=============
Release Notes
=============

0.0.1 release
=============

Initial development release.