=======================
|project| Documentation
=======================

.. mdinclude:: ../../README.md

|project| is a light command-line interface for Cable3d.

.. _main-toc:

Contents
========

.. toctree::
    :maxdepth: 2

    api
    releases
    todo-list
