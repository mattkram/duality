"""This module provides the command-line interface for building Sphinx documentation."""
import os
import re

import click

import seamoor


def build(source_dir, build_dir, venv):
    """Use sphinx-build to build docs."""
    command = f"sphinx-build {source_dir} {build_dir}"
    if venv:
        command = os.path.join(venv, "Scripts", command)
    os.system(command)


def build_auto(source_dir, build_dir, watch_dir):
    """Use sphinx-autobuild to build docs."""
    build_opts = " ".join(
        [
            "--ignore *.pyc",
            "--ignore *.swp",
            "--ignore *.swx",
            "--ignore *.log",
            "--ignore *.*~",
            "--ignore *___jb_*___",
            "--watch {}".format(watch_dir),
        ]
    )
    os.system(f"sphinx-autobuild {build_opts} {source_dir} {build_dir}")


@click.command()
@click.argument("out_dir", required=False, default="build")
@click.option("--auto", default=False, is_flag=True, help="Turn on auto-build mode.")
@click.option(
    "--release",
    default=False,
    is_flag=True,
    help="Turn on frozen release mode to save under specific version number.",
)
@click.option("--branch")
@click.option("--venv", type=str)
def main(out_dir, auto, release, branch, venv):
    """Compile Sphinx documentation.

    If OUT_DIR is not specified, $USERPROFILE\dev\docs\grampa is assumed.

    """
    project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    source_dir = os.path.abspath(os.path.join(project_dir, "docs", "source"))
    module_dir = os.path.abspath(os.path.join(project_dir, "src", "seamoor"))

    if branch:
        if re.search("\d+", branch):
            build_dir = os.path.join(out_dir, branch)
        else:
            build_dir = os.path.join(out_dir, "latest")
    elif release:
        build_dir = os.path.join(out_dir, seamoor.__version__)
    else:
        build_dir = os.path.join(out_dir, "latest")

    if auto:
        build_auto(source_dir, build_dir, module_dir)
    else:
        build(source_dir, build_dir, venv)


if __name__ == "__main__":
    main()
