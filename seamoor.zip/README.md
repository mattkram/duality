# seamoor
A light wrapper for mooring analysis with Cable3d
