import codecs
import os

from setuptools import setup, find_packages

PROJECT_NAME = "seamoor"

here = os.path.abspath(os.path.dirname(__file__))

with codecs.open(os.path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = "\n" + f.read()

about = {}

with open(os.path.join(here, "src", PROJECT_NAME, "__version__.py")) as f:
    exec(f.read(), about)

# Specific requirements for installation
requirements = [
    "click",
    "click-log",
    "numpy",
    "toml",
]

setup(
    name=PROJECT_NAME,
    version=about["__version__"],
    description="A simple CLI wrapper for cable3d",
    long_description=long_description,
    author="Matthew Kramer",
    author_email="mkramer@chevron.com",
    license="MIT",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    entry_points={
        "console_scripts": [
            "seamoor=seamoor.cli:cli",
        ]
    },
    install_requires=requirements,
)
