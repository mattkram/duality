#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <string>
#include <fstream>

#include "fortranInterface.h"
#include "Cable3dInterface.hh"

using std::cout;
using std::endl;

namespace convert {

const double ft2m = 0.3048;
const double lb2N = 4.44822;

} // namespace convert

// Default constructor
Cable3dInterface::Cable3dInterface(void) :
    debug_(false),
    numPrevIterations_(0),
    isLoaded_(false), 
    maxTimeStep_(0.1),
    starMotion_(),
    infile_("MOOR.INP"),
    outfile_("output.dat") {}

Cable3dInterface::Cable3dInterface(bool debug) :
    debug_(debug),
    numPrevIterations_(0),
    isLoaded_(false), 
    maxTimeStep_(0.1),
    starMotion_(),
    infile_("MOOR.INP"),
    outfile_("output.dat") {}

void Cable3dInterface::setInputFile(std::string infile) {
    infile_ = infile;
}

void Cable3dInterface::setOutputFile(std::string outfile) {
    outfile_ = outfile;
}

std::string getEnvVar(std::string const& key, std::string const& defaultVal) {
    char const* val = std::getenv(key.c_str());
    return val == NULL ? defaultVal : std::string(val);
}

// Function to initialize mooring system from dictionary
void Cable3dInterface::loadFiles() {
    
    // Do something to initialize the mooring system
    cout << "  Initializing Cable3d mooring system" << endl;
   
//    std::string path_str = getEnvVar("CABLE3D_RUN_DIR", "");
    std::string path_str = getEnvVar("HOME", "") + "/cable3d_tmp";
    std::string infile_str = getEnvVar("CABLE3D_INPUT_FILE", "MOOR.INP");
    std::string outfile_str = getEnvVar("CABLE3d_OUTPUT_FILE", "RESULTS.OUT");

    const int STR_LEN = 200;
    char path[160];
    char infile[STR_LEN];
    char outfile[STR_LEN];
    
    sprintf(path, "%s", path_str.c_str());
    sprintf(infile, "%s", infile_str.c_str());
    sprintf(outfile, "%s", outfile_str.c_str());

    cout << "    Cable3dInterface: Run path:    \"" << path << "\"" << endl;
    cout << "    Cable3dInterface: Input file:  \"" << infile << "\"" << endl;
    cout << "    Cable3dInterface: Output file: \"" << outfile << "\"" << endl;

    for (int i=0; i < 160; ++i) {
        if (i >= path_str.length()) {
            path[i] = ' ';
        }
    }

    for (int i=0; i < STR_LEN; ++i) {
        if (i >= infile_str.length()) {
            infile[i] = ' ';
        }
        if (i >= outfile_str.length()) {
            outfile[i] = ' ';
        }
    }

    initializefromfiles_(infile, outfile, path);
    readinputfiles_();

    gettimestep_(&maxTimeStep_);
    isLoaded_ = true;

    if (debug_) {
        cout << "After loading for interface " << this << ", isLoaded_ = " << isLoaded_ << endl;
        cout << "Max time step loaded from cable3d: " << maxTimeStep_ << endl;
//        fout_ = fopen("cable3d_interp.csv", "w");
    }
            
} 

void Cable3dInterface::updateCable3d(Real time, Real timeStep, CoordReal translation[3], CoordReal rotation[3], bool isFirstPartition) {
    
    // Update Cable3d based on the current position.
//    cout<< "Is first partition: " << isFirstPartition << endl;
    if (!isLoaded_) {
//        if (isFirstPartition) {
            loadFiles();
//        } else {
//            printf("Right before infinite loop\n");
//            printf("isLoaded_: %u\n", isLoaded_);
////            while (!isLoaded_) {
////                // wait
////                cout<< "Waiting for input files to be loaded." << endl;
////            }
//      }
//    } else {
//        while (!isLoaded_) {
//            // wait
//            cout<< "Waiting for input files to be loaded." << endl;
//        }
    }
    if (debug_) {
        cout << "isLoaded_ after load during normal call: " << isLoaded_ << ", " << this << endl;
    }

    // Blank arrays where cable3d will take motion and put its force/moment
    double c3dMotion[6];
    double c3dForce[6];
    

    // Update the results by splitting motion into several steps
//    if (isFirstPartition and time > currentTime_) {
    if (time > currentTime_) {
        
        double starTimeStep = time - currentTime_;
        
        if (debug_) {
            // Limit time step to be less than max time step, and to be an integer divisor of star-ccm+ timestep
            cout << "Target time step: " << timeStep << endl;
            cout << "Maximum time step: " << maxTimeStep_ << endl;
        }
        
        // Adjust time step such that it is less than maxTimeStep_ and fits into 
        // input argument an integer number of times.
        // Use of ceil ensures it is less than max.
        int numSteps = ceil(timeStep / maxTimeStep_); 
        timeStep /= numSteps;
   
        if (debug_) { 
            cout<< "Adjusted time step: " << timeStep << endl;
        }
        
        // Store position in starMotion stack array
        for (int i=0; i < 6; ++i) {
            // Move positions back one index
            for (int j=kMaxNumPrevIterations_; j > 0; --j) {
                starMotion_[j][i] = starMotion_[j-1][i];
            }
            
            // Store current position in index 0
            if (i < 3) {
                starMotion_[0][i] = translation[i];
            } else {
                starMotion_[0][i] = rotation[i-3];
            }

        }
        
        // Increment number of previous iterations to use
        if (numPrevIterations_ < kMaxNumPrevIterations_) { 
            ++numPrevIterations_;
        }
        
        if (debug_) {
            cout<< "Number of previous iterations to use: " << numPrevIterations_ << endl;
        }

        // Map of star-ccm+ direction to cable3d. The magnitude is the index, the sign denotes the multiplier 
        int indexMap[] = {0, 2, 1, 3, 5, 4}; 
        int sign[] = {1, -1, 1, 1, -1, 1};

        // Loop through number of sub-time steps
        for (int i=0; i < numSteps; ++i) {
            currentTime_ += timeStep;
            if (debug_) {
                cout<< "Current Time: " << currentTime_ << endl;
            }
            // Store translation and rotation into 6DoF motion array to pass to cable3d
            for (int j=0; j < 6; ++j) { // loop through star-ccm positions
                int c3dIndex = indexMap[j];
                if (numPrevIterations_ == 1) { 
                    // Step fraction
                    double f = static_cast<double>(i+1) / numSteps;
                     
                    // Use linear interpolation
                    c3dMotion[c3dIndex] = sign[j] * (f * starMotion_[0][j] + (1 - f) * starMotion_[1][j]);

                } else if (numPrevIterations_ == 2) {
                    // Use quadratic interpolation
                    double timePts[3];
                    double motionPts[3];
                    for (int k=0; k < 3; ++k) {
                        timePts[k] = time - k * starTimeStep;
                        motionPts[k] = starMotion_[k][j];
                    }
                    c3dMotion[c3dIndex] = sign[j] * quadraticFit(timePts, motionPts, currentTime_);
                }
            }

            // Convert translations to feet 
//            for (int j=0; j < 3; ++j) {
//                c3dMotion[j] /= convert::ft2m;   
//            }
    
            // Call cable3d based on current time and motion 
            callcable3d_(&currentTime_, &timeStep, c3dMotion, c3dForce);
           
            // Print results to console for debugging 
//            if (debug_) {
                cout<< endl;
                cout<< "Cable3d Time: " << currentTime_ << endl;
                    
                cout<< "Cable3d Motion:" << endl << "[";
                for (int j=0; j < 6; ++j) {
                    cout<< " " << c3dMotion[j];
                }
                cout << "]" << endl;
//            }
        }
      
        // Force current time to be equal to input time 
        // (otherwise, floating point prevents proper comparison in if statement)
        currentTime_ = time;
         
        // Store force and moment in class attributes
        for (int i=0; i < 3; ++i) {
            starForce_[i] = sign[i] * c3dForce[indexMap[i]];
            starMoment_[i] = sign[i+3] * c3dForce[indexMap[i+3]];
        }
        
        // Convert force and moment from US to SI units
//        for (int i=0; i < 3; ++i) {
//            starForce_[i] *= convert::lb2N;
//            starMoment_[i] *= convert::lb2N * convert::ft2m;
//        }
       
        // Print results to console for debug_ging 
//        if (debug_) {
            cout << "Cable3d Force & Moment:" << endl << "[";
            for (int i=0; i < 6; ++i) {
                cout << " " << c3dForce[i];
            }
            cout << "]" << endl << endl;
//        }
    }
}

double* Cable3dInterface::getForce(Real time, Real timeStep, CoordReal *translation, CoordReal *rotation, bool isFirstPartition) {
    // Update starInterface (if needed)
    updateCable3d(time, timeStep, translation, rotation, isFirstPartition);
    return starForce_;
}
    
double* Cable3dInterface::getMoment(Real time, Real timeStep, CoordReal *translation, CoordReal *rotation, bool isFirstPartition) {
    // Update starInterface (if needed)
    updateCable3d(time, timeStep, translation, rotation, isFirstPartition);
    return starMoment_;
}

double quadraticFit(double t[3], double x[3], double ti) {

    double A[3][3] = {0};
    for (int i=0; i < 3; ++i) {
        for (int j=0; j < 3; ++j) {
            A[i][j] = pow(t[i], j);
        }
    }

    // Invert the matrix
    double Ainv[3][3] = {0};
    Ainv[0][0] = +(A[2][2]*A[1][1] - A[2][1]*A[1][2]);
    Ainv[1][0] = -(A[2][2]*A[1][0] - A[2][0]*A[1][2]);
    Ainv[2][0] = +(A[2][1]*A[1][0] - A[2][0]*A[1][1]);
    Ainv[0][1] = -(A[2][2]*A[0][1] - A[2][1]*A[0][2]);
    Ainv[1][1] = +(A[2][2]*A[0][0] - A[2][0]*A[0][2]);
    Ainv[2][1] = -(A[2][1]*A[0][0] - A[2][0]*A[0][1]);
    Ainv[0][2] = +(A[1][2]*A[0][1] - A[1][1]*A[0][2]);
    Ainv[1][2] = -(A[1][2]*A[0][0] - A[1][0]*A[0][2]);
    Ainv[2][2] = +(A[1][1]*A[0][0] - A[1][0]*A[0][1]);
    
    double det =  A[0][0] * (A[2][2]*A[1][1] - A[2][1]*A[1][2])
                - A[1][0] * (A[2][2]*A[0][1] - A[2][1]*A[0][2])
                + A[2][0] * (A[1][2]*A[0][1] - A[1][1]*A[0][2]);
    
    // Calculate coefficients via Ainv dot x
    double coeff[3] = {0};
    for (int i=0; i < 3; ++i) {
        for (int j=0; j < 3; ++j) {
            coeff[i] += Ainv[i][j] * x[j] / det;       
        }
    }

    double value = 0.0;
    for (int i=0; i < 3; ++i) {
        value += pow(ti, i) * coeff[i];
    }
    return value;
}

