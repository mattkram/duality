#ifndef CABLE3D_INTERFACE_HH
#define CABLE3D_INTERFACE_HH

#include <string>
#include <stdio.h>
#include "uclib.h" // Include for typedef's

class Cable3dInterface {

  private:
    // Flag for debug mode
    const bool debug_;
   
    std::string infile_;
    std::string outfile_;
     
    double maxTimeStep_;
    double currentTime_;

    // Set interpolation to linear (1) or quadratic (2)
    const static int kMaxNumPrevIterations_ = 2;
    int numPrevIterations_;
   
    // Previous translation and rotation from Star. First index is number
    // of timesteps back, second is direction.
    // e.g. starMotion_[2][0] is the x-translation from two iterations ago.
    double starMotion_[kMaxNumPrevIterations_+1][6];

    // Arrays used to return force and moment to star
    double starForce_[3];
    double starMoment_[3];

    // Variable and method to load Cable3d input files and mark as loaded
    bool isLoaded_;
    void loadFiles(void);

  public:
    Cable3dInterface(void);
    Cable3dInterface(bool);

    void setInputFile(std::string);
    void setOutputFile(std::string);
    void updateCable3d(Real, Real, CoordReal*, CoordReal*, bool);
    double* getForce(Real, Real, CoordReal*, CoordReal*, bool);
    double* getMoment(Real, Real, CoordReal*, CoordReal*, bool);

};

// General helper math/linear algebra functions
double quadraticFit(double*, double*, double);

#endif // CABLE3D_INTERFACE_HH
