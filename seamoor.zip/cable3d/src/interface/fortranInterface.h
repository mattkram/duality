#ifndef FORTRAN_INTERFACE_H
#define FORTRAN_INTERFACE_H

#ifdef __cplusplus
extern"C" {
#endif
    void callcable3d_(double*, double*, double[], double[]);
    void getfilenames_();
    void readinputfiles_();
    void initializestatics_();
    void initializefromfiles_(char[], char[], char[]);
    void gettimestep_(double*);
    void writesystemstate_();
#ifdef __cplusplus
}
#endif

#endif // FORTRAN_INTERFACE_H
