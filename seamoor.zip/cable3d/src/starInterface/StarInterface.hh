#ifndef STAR_INTERFACE_H
#define STAR_INTERFACE_H

#include "uclib.h" // Include for typedef's

// These function definitions are used to define the interface called by 
// Star-CCM+ user-defined field functions.
#ifdef __cplusplus
extern "C" {
#endif
extern void getMooringForce(Real (*result)[3], int size, 
                            Real *time, 
                            Real *timeStep, 
                            CoordReal (*translation)[3],
                            CoordReal (*rotation)[3],
                            Real *partition); 

extern void getMooringMoment(Real (*result)[3], int size, 
                            Real *time, 
                            Real *timeStep, 
                            CoordReal (*translation)[3],
                            CoordReal (*rotation)[3],
                            Real *partition); 
#ifdef __cplusplus
}
#endif

#endif // STAR_INTERFACE_H
