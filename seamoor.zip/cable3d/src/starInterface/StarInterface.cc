#include "Cable3dInterface.hh"
#include "StarInterface.hh"
#include <iostream>
#include <cstdio>

using std::cout;
using std::endl;

// Initialize the StarInterface object
static Cable3dInterface cable3dInterface;

void getMooringForce(Real (*result)[3], int size, 
                     Real *time, 
                     Real *timeStep, 
                     CoordReal (*translation)[3],
                     CoordReal (*rotation)[3],
                     Real *partition) {

    //only do something if the length of dxFromReport is non zero
    if (size > 0){

//        printf("In getMooringForce, Partition Number: %f, Interface address: %p\n", partition[0], &cable3dInterface);
//        cout << "Partition: " << partition[0] << endl;
         
        bool isFirstPartition = true; //(partition[0] == 0 or partition[0] == 1);

        // Get force from Cable3d
        double* force = cable3dInterface.getForce(*time, *timeStep, translation[0], rotation[0], isFirstPartition);
    
//        printf("Position: x = %f, y = %f\n", translation[0][0], translation[0][1]);
//        std::cout<< "Force:" << force[0][0] << force[0][1] << std::endl;

        // Store the force values in result array
        for(int i=0; i < size; ++i) {
            for (int j=0; j < 3; ++j) {
                result[i][j] = force[j];
            }
        }
    }
}

void getMooringMoment(Real (*result)[3], int size, 
                      CoordReal *time, 
                      CoordReal *timeStep, 
                      CoordReal (*translation)[3],
                      CoordReal (*rotation)[3],
                      Real *partition) {

    //only do something if the length of dxFromReport is non zero
    if (size > 0){

//        printf("In getMooringMoment, Partition Number: %f, Interface address: %p\n", partition[0], &cable3dInterface);
        
        bool isFirstPartition = true; //(true or partition[0] == 0 or partition[0] == 1);
        
        // Get moment from Cable3d
        double* moment = cable3dInterface.getMoment(*time, *timeStep, translation[0], rotation[0], isFirstPartition);
    
        // Store the moment values in result array
        for(int i=0; i < size; ++i) {
            for (int j=0; j < 3; ++j) {
                result[i][j] = moment[j];
            }
        }
    }
}

