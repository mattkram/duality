#include "uclib.h"
#include "StarInterface.hh"

void uclib() {

    // Define name of mooring function 
    ucfunc(getMooringForce, "VectorFieldFunction", "MooringForce");
    ucfunc(getMooringMoment, "VectorFieldFunction", "MooringMoment");
  
    // Define arguments for mooring function
    ucarg(getMooringForce, "Cell", "$Time", sizeof(Real));
    ucarg(getMooringForce, "Cell", "$TimeStep", sizeof(Real));
    ucarg(getMooringForce, "Cell", "$$HullTranslation", sizeof(CoordReal[3]));
    ucarg(getMooringForce, "Cell", "$$HullRotation", sizeof(CoordReal[3]));
    ucarg(getMooringForce, "Cell", "$PartitionId", sizeof(Real));
      
    ucarg(getMooringMoment, "Cell", "$Time", sizeof(Real));
    ucarg(getMooringMoment, "Cell", "$TimeStep", sizeof(Real));
    ucarg(getMooringMoment, "Cell", "$$HullTranslation", sizeof(CoordReal[3]));
    ucarg(getMooringMoment, "Cell", "$$HullRotation", sizeof(CoordReal[3]));
    ucarg(getMooringMoment, "Cell", "$PartitionId", sizeof(Real));

} 
