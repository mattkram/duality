// STAR-CCM+ macro: runStarTestNew.java
// Written by STAR-CCM+ 11.06.011
package macro;

import java.util.*;

import star.common.*;
import star.base.neo.*;

public class runStarTestNew extends StarMacro {

  public void execute() {
    execute0();
  }

  private void execute0() {

    Simulation simulation_0 = 
      getActiveSimulation();

    Solution solution_0 = 
      simulation_0.getSolution();

    solution_0.clearSolution();

    simulation_0.getSimulationIterator().step(1);
  }
}
