package macro;

import java.util.*;
import java.io.*;

import star.common.*;
import CVXStar.*;

public class runStarTest extends StarSimCVX {

  public void execute() {
    execute0();
  }

  private void execute0() {
    
    // Variables that will be replaced by sed command from shell script
    // Required to initialize StarSimCVX    
    initialize();
    clearSolution();
    generateMesh();
    initializeSolution();

    setInnerIterations(1);
    run();

    writeMonitors("resultsStar.csv", new String[] {"mooring_dx",
                                                   "mooring_dy",
                                                   "mooring_Fx",
                                                   "mooring_Fy"});
  } 

}
