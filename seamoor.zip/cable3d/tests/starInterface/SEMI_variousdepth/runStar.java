// STAR-CCM+ macro: runStar.java
// Written by STAR-CCM+ 11.02.009
package macro;

import java.util.*;

import star.common.*;

public class runStar extends StarMacro {

  public void execute() {
    execute0();
  }

  private void execute0() {

    Simulation simulation_0 = 
      getActiveSimulation();

    Solution solution_0 = 
      simulation_0.getSolution();

    solution_0.initializeSolution();

    simulation_0.getSimulationIterator().run();
  }
}
