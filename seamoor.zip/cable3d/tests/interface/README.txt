This folder contains test cases to test the interface between C++ and Cable3d.
