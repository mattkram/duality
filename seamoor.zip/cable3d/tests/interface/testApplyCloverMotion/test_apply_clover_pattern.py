#!/usr/bin/env python
# The tests in this module ensure that the tensions are identical when the program is run with
# different sets of lines
import os
import unittest

import numpy

from run import main


class TestCloverPattern(unittest.TestCase):

    def setUp(self):
        self.base_case_dir = 'case_files'

    def compare_line_tensions(self, line_num,  *case_dirs):
        tensions = []
        for case_dir in case_dirs:
            filename = os.path.join(self.base_case_dir, case_dir, 'mtmhis{0}.out'.format(line_num))
            tension = numpy.loadtxt(filename, skiprows=1, unpack=True, usecols=(4, ))
            tensions.append(tension)

        for ti, tj in zip(*tensions):
            self.assertEqual(ti, tj)

    def test_line_tensions(self):
        self.compare_line_tensions(5, '5678', '0056')
        self.compare_line_tensions(6, '5678', '0056')
        self.compare_line_tensions(7, '5678', '0078')
        self.compare_line_tensions(8, '5678', '0078')


if __name__ == '__main__':
    unittest.main()
