#!/usr/bin/env python
# This script plots the results, comparing identical line results over each other in different
# subplots.
import os
import re
from fnmatch import fnmatch

import numpy
from matplotlib import pyplot

base_case_dir = 'case_files'
dirs = sorted([d for d in os.listdir(base_case_dir) if re.match('\d+', d)], reverse=False)

sty = ['b-', 'r-', 'g-o']
all_lines = sorted(list(set([l for l in d for d in dirs])))

fig = pyplot.figure(figsize=(20, 10))
ax = [pyplot.subplot2grid((4, 2), (0, 0), rowspan=len(all_lines))]
ax += [pyplot.subplot2grid((len(all_lines), 2), (i, 1)) for i in range(len(all_lines))]

for d, styi in zip(dirs, sty):
    lines = [l for l in d if l != '0']

    for line in lines:
        filename = os.path.join(base_case_dir, d, 'mtmhis{0}.out'.format(line))
        time, x, y, z, tension = numpy.loadtxt(filename, skiprows=1, unpack=True, usecols=(0, 1, 2, 3, 4))

        if line == '5':
            x -= 111.55
            z -= 111.55
        elif line == '7':
            x -= 115.49
            z -= -93.18

        if line == lines[0]:
            ax[0].plot(x, z, styi)
            ax[0].set_title('CG Position')
            ax[0].set_xlabel('x [ft]')
            ax[0].set_ylabel('y [ft]')

        i = all_lines.index(line) + 1
        ax[i].set_title('Line {0}'.format(line))
        ax[i].plot(time, tension, styi, label=d, markerfacecolor='none')
        ax[i].legend(loc='best')
        ax[i].set_xlabel('Time [s]')
        ax[i].set_ylabel('Tension [lbs]')
pyplot.tight_layout()

pyplot.savefig('results_comparison.png', format='png')

pyplot.show()
