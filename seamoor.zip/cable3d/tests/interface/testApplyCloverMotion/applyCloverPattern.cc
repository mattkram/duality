#include <iostream>
#include <stdio.h>
#include <math.h>
#include "Cable3dInterface.hh"
#include "fortranInterface.h"

using namespace std;


int main(int argc, char *argv[]) {

    char infile[200] = "";
    char outfile[200] = "";
    char rundir [160] = "";

    if (argc == 1) {
        getfilenames_();
    } else if (argc == 3) {
        cout<< sizeof(argv[1]) << sizeof(argv[2]) << endl;
        for (int i=0; i < 200; ++i) {
            if (i < sizeof(argv[1])) {
                infile[i] = argv[1][i];
            } else {
                infile[i] = 0;
            }
            if (i < sizeof(argv[2])) {
                outfile[i] = argv[2][i];
            } else {
                outfile[i] = 0;
            }
        }
        cout<< infile << " " << outfile << endl;
        initializefromfiles_(infile, outfile, rundir);
    } else {
        cout<< "Must provide 0 or 2 command line arguments" << endl;
        return 1;
    }

    FILE * ff; 
    ff = fopen("timeHistory.csv", "w");

    readinputfiles_();
           
    double time = 0;
    double dt = 0.1;
    double force[6];
    double motion[6];

    double omg = 0.01 * M_PI;
    double maxTime = M_PI / omg * 2;
    
    // Initialize force and motion vectors to zero
    for (int i=0; i < 6; ++i) {
        force[i] = 0.0;
        motion[i] = 0.0;
    }

    // Loop through time
    fprintf(ff, "Time,Fx,Fy,Fz,Mx,My,Mz\n");

    while (time <= maxTime) {
        motion[0] =  40*0.3048*sin(4*omg*time) * cos(omg*time);
        motion[2] = -40*0.3048*sin(4*omg*time) * sin(omg*time);

        callcable3d_(&time, &dt, motion, force);
        fprintf(ff, "%10.2f", time);
        printf("Time: %10.2f\n", time);
        for (int i=0; i<6; ++i) {
            fprintf(ff, ",%10.1f", force[i]);
        }
        fprintf(ff, "\n");
        time += dt;
    }

    fclose(ff);
    return 0;

}
