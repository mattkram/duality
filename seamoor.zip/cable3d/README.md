# Cable3d

Cable3d is a legacy mooring dynamics code used for coupling with CFD codes.

## Cloning the verification submodule

The verification cases are kept in a separate repository to minimize size of the main repo.

```git clone --recursive http://github.chevron.com/FOSC/cable3d.git```

## Building the docs

The documentation can be built with Sphinx

* Install the Python dependencies:

    ```pipenv install```

* Build the docs

    ```python docs/build-docs.py```

* Alternatively, build the docs with auto-updating mode:

    ```python docs/build-docs.py --auto```