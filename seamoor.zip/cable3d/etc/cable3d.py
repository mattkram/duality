#!/usr/bin/env python
import errno
import os
import re
import shutil

def mkdir_p(path):
    '''Create directory if it doesn't exist'''
    try:
        os.makedirs(path)
    except OSError as exc:
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            raise

def copy_system_files(config, source_dir, destination_dir):

    config_file = '{}.INP'.format(config)

    # Read config_file line-by-line looking for input files
    input_files = []
    with open(os.path.join(source_dir, config_file), 'rb') as fff:
        for line in fff:
            match = re.search('\w+\.inp', line)
            if match:
                input_files.append(match.group(0))

    data_files = []
    for input_file in input_files:
        with open(os.path.join(source_dir, input_file), 'rb') as fff:
            for line in fff:
                match = re.search('\w+\.dat', line)
                if match:
                    data_files.append(match.group(0))

    all_files = set([config_file] + input_files + data_files)
    for f in all_files:
        mkdir_p(destination_dir)
        shutil.copy(os.path.join(source_dir, f), os.path.join(destination_dir, f))

def run_command(command, case_dir='.'):
    old_pwd = os.getcwd()
    os.chdir(case_dir)
    os.system(command)
    os.chdir(old_pwd)
