import logging
import os
import sys

from .__version__ import __version__

logger = logging.getLogger("seamoor")
logger.setLevel(logging.INFO)

root_dir = os.path.abspath(os.path.dirname(__file__))
bin_dir = os.path.join(root_dir, "bin")

_windows = sys.platform.startswith("win")
if _windows:
    cable3d_exe = os.path.join(bin_dir, "C3Da.exe")
