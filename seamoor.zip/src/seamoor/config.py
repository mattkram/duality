import os

import toml

DEFAULT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "defaults"))


def load_toml_file(filename):
    with open(filename, "r") as f:
        return toml.load(f)


class Attribute(object):
    def __init__(self, key=None, **kwargs):
        self.name = None
        self.key = key
        self.type_ = kwargs.get("type", None)

    @property
    def keys(self):
        if self.key is None:
            return [self.name]
        return self.key.split(".")

    def __set_name__(self, _, name):
        self.name = name

    def __set__(self, instance, value):
        if self.type_ is not None:
            value = self.type_(value)
        instance.__dict__[self.name] = value

    def __get__(self, instance, _):
        return instance.__dict__[self.name]


class Configuration(object):
    toml_filename = ""

    def __init__(self, directory=DEFAULT_DIR):
        if self.toml_filename:
            self.load_from_toml(os.path.join(DEFAULT_DIR, self.toml_filename))
            if directory != DEFAULT_DIR:
                self.load_from_toml(os.path.join(directory, self.toml_filename))

    def load_from_dict(self, dict_):
        dict_ = dict(dict_)
        for attr in self.__class__.__dict__.values():
            if isinstance(attr, Attribute):
                value = dict(dict_)
                try:
                    for key in attr.keys:
                        value = value[key]
                except KeyError:
                    pass
                else:
                    setattr(self, attr.name, value)

    def load_from_toml(self, filename):
        dict_ = load_toml_file(filename)
        self.load_from_dict(dict_)


class Environment(Configuration):
    toml_filename = "environment.toml"

    current_filename = "current.dat"
    wave_filename = "waves.dat"

    wave_amplitude = Attribute("wave.amplitude", type=float)
    wave_frequency = Attribute("wave.frequency", type=float)
    wave_direction = Attribute("wave.direction", type=float)

    current_depth = Attribute("current.depth", type=list)
    current_x_velocity = Attribute("current.x_velocity", type=list)
    current_y_velocity = Attribute("current.y_velocity", type=list)
    current_z_velocity = Attribute("current.z_velocity", type=list)


class Parameter(Configuration):
    output_filename = "params.dat"
    relaxation = Attribute(type=float)
    structural_damping = Attribute(type=float)
    ramping_constant = Attribute(type=float)
    beta = Attribute(type=float)
    gamma = Attribute(type=float)
    tolerance = Attribute(type=float)
    max_iterations = Attribute(type=int)
    start_time = Attribute(type=float)
    end_time = Attribute(type=float)
    time_step = Attribute(type=float)
    water_density = Attribute(type=float)
    contents_density = Attribute(type=float)
    gravity = Attribute(type=float)
    water_depth = Attribute(type=float)


class RunConfig(Configuration):
    job_number = Attribute("job", type=int)
    job_motion = Attribute("jmotn", type=int)


class Filename(Configuration):
    cg_tension = Attribute(type=str)
    results = Attribute(type=str)


class System(Configuration):
    toml_filename = "system.toml"

    output_filename = Attribute(type=str)
    description = Attribute(type=str)
    reference_location = Attribute(type=list)
    initial_displacement = Attribute(type=list)
    initial_rotation = Attribute(type=list)
    line_filenames = Attribute("lines", type=list)

    def __init__(self, directory=DEFAULT_DIR):
        self.parameter = Parameter()
        self.run = RunConfig()
        self.filename = Filename()
        self.section_types = []
        self.lines = []

        super().__init__(directory)
        self.load_section_types(directory)
        self.load_lines(directory)

    def load_from_dict(self, dict_):
        super().load_from_dict(dict_)
        self.parameter.load_from_dict(dict_["parameter"])
        self.run.load_from_dict(dict_["run"])
        self.filename.load_from_dict(dict_["filename"])

    def load_section_types(self, directory):
        self.section_types = SectionType.load_from_toml(directory)

    def load_lines(self, directory):
        self.lines = []
        for line_filename in self.line_filenames:
            line = Line()
            line.system = self
            line.load_from_toml(os.path.join(directory, line_filename))
            self.lines.append(line)


class Segment(Configuration):
    length = Attribute(type=float)
    _num_elements = Attribute("num_elements", type=int)
    target_length = Attribute(type=float)
    type_name = Attribute("type", type=str)

    def __init__(self, line):
        super().__init__()
        self.line = line

    @property
    def num_elements(self):
        if self._num_elements:
            return self._num_elements
        elif self.target_length:
            return self.length // self.target_length + 1
        raise AttributeError(
            "Either num_elements or target_length must be specified for a segment"
        )

    @property
    def section_type(self):
        for t in self.line.system.section_types:
            if t.name == self.type_name:
                return t
        raise NameError(
            f'Section type "{self.type_name}" doesn\'t exist in sections.toml'
        )


class SectionType(Configuration):
    name = Attribute(type=str)
    element_type = Attribute(type=int)
    youngs_modulus = Attribute(type=float)
    moment_of_inertia = Attribute(type=float)
    cross_sectional_area = Attribute(type=float)
    internal_cavity_area = Attribute(type=float)
    outer_fiber_distance = Attribute(type=float)
    hydrodynamic_diameter = Attribute(type=float)
    normal_drag_coefficient = Attribute(type=float)
    axial_drag_coefficient = Attribute(type=float)
    added_mass_coefficient = Attribute(type=float)
    mass_per_unit_length = Attribute(type=float)
    buoyant_force_per_unit_length = Attribute(type=float)

    @classmethod
    def load_from_toml(cls, directory):
        dict_ = load_toml_file(os.path.join(directory, "sections.toml"))

        section_types = []
        for section in dict_["section"]:
            section_type = SectionType()
            section_type.load_from_dict(section)
            section_types.append(section_type)

        return section_types


class Results(Configuration):
    nodal_output_frequency = Attribute(type=int)
    snapshot_frequency = Attribute(type=int)

    output_nodes = Attribute(type=list)
    write_displacement = Attribute(type=bool)
    write_slope = Attribute(type=bool)
    write_velocity = Attribute(type=bool)
    write_angular_velocity = Attribute(type=bool)
    write_tension = Attribute(type=bool)
    write_bending_moment = Attribute(type=bool)
    write_shear_force = Attribute(type=bool)
    write_current_force = Attribute(type=bool)


class Line(Configuration):
    toml_filename = "line.toml"

    name = Attribute(type=str)
    pretension = Attribute(type=float)
    top_coordinates = Attribute(type=list)
    bottom_coordinates = Attribute(type=list)

    def __init__(self, directory=DEFAULT_DIR):
        self.system = None
        self.results = Results()
        self.segments = []
        super().__init__(directory)

    @property
    def num_segments(self):
        return len(self.segments)

    def load_from_dict(self, dict_):
        super().load_from_dict(dict_)
        self.results.load_from_dict(dict_["results"])
        self.segments = []
        for segment_dict in dict_["segment"]:
            segment = Segment(line=self)
            segment.load_from_dict(segment_dict)
            self.segments.append(segment)
