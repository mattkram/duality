"""An object-oriented interface to Cable3d."""
import os
import subprocess

from seamoor import cable3d_exe, _windows
from seamoor.config import System, Environment

from . import logger


# TODO: Consider using jinja2 instead of manual string writing


class Model(object):
    """A case handler that builds a global-performance model and outputs Cable3d input files."""

    def __init__(self):
        self.system = System()
        self.environment = Environment()

    def run_pre_statics(self, case_dir):
        logger.info("Running pre-statics")
        self.system.run.job_number = 0
        self.system.parameter.relaxation = 0.1
        self.write(case_dir)
        self.execute(case_dir)

    def write(self, case_dir):
        """Write the Cable3d case files to the directory."""
        logger.info("Writing Cable3d input files.")

        os.makedirs(case_dir, exist_ok=True)

        self._write_environment(case_dir)
        self._write_line_files(case_dir)
        self._write_system_file(case_dir)
        self._write_numerical_parameters(case_dir)

    def execute(self, case_dir, silent=False):
        input_file = self.system.output_filename
        output_file = os.path.splitext(input_file)[0] + ".out"

        kwargs = {}
        if silent:
            kwargs["stdout"] = subprocess.PIPE

        process = subprocess.Popen(
            [cable3d_exe], cwd=str(case_dir), stdin=subprocess.PIPE, **kwargs
        )

        def send_input(string):
            if _windows:
                process.stdin.write((string + "\r\n").encode("utf-8"))
            else:
                raise NotImplementedError(
                    "Currently cannot run on non-Windows platforms"
                )

        send_input(input_file)
        send_input(output_file)
        send_input("1")

        process.communicate()

        if (
            not os.path.exists(os.path.join(case_dir, output_file))
            or process.poll() != 0
        ):
            raise ChildProcessError("Error executing Cable3d")

    def _write_environment(self, case_dir):
        """Write the environment files, including current profile and wave param."""
        env = self.environment

        current_profile = [
            [-d for d in env.current_depth],
            env.current_x_velocity,
            env.current_y_velocity,
            env.current_z_velocity,
        ]

        # Write the current data file
        filename = os.path.join(case_dir, env.current_filename)
        with OutputFile(filename) as fff:
            fff.write("a. Currents")
            fff.write()
            fff.write(
                "{:6d}",
                len(current_profile[0]),
                description="# of depths for currents (>0 = p. linear, <0 = poly.)",
                width=13,
            )
            fff.write()
            fff.write("     depth        x-vel       y-vel       z-vel")
            for row in zip(*current_profile):
                fff.write("{:12.5f}" * len(row), *row)

        # Write the wave file
        filename = os.path.join(case_dir, env.wave_filename)
        with OutputFile(filename) as fff:
            fff.write("b. Waves")
            fff.write()
            fff.write(
                "{:12.5f}" * 2,
                env.wave_amplitude,
                env.wave_frequency,
                description="wave amplitude and frequency (rad/sec)",
                width=30,
            )
            fff.write(
                "{:12.5f}",
                env.wave_direction,
                description="wave direction relative to x axis",
                width=30,
            )

    def _write_line_files(self, case_dir):
        """Write a file for a single line."""

        lines = self.system.lines

        # Create a list of all unique used section types
        used_line_types = []
        for line in lines:
            for segment in line.segments:
                if segment.section_type not in used_line_types:
                    used_line_types.append(segment.section_type)

        self._write_line_types(used_line_types, case_dir)

        # Add each line
        for index, line in enumerate(lines, start=1):
            # Calculate the number of elements in each section
            num_elements = []
            for segment in line.segments:
                num_elements.append(segment.num_elements)

            # Write the riser data to the input file
            filename = os.path.join(case_dir, "{}.inp".format(line.name))
            width = 13
            with OutputFile(filename) as fff:

                # Write Header Code
                fff.write("Input for {}, written by seamoor", line.name)
                fff.write()
                fff.write("I. Global Constants")
                fff.write()
                fff.write("a. Indexs")
                fff.write()
                fff.write(
                    "{:6d}",
                    sum(num_elements) + 1,
                    description="NODE   (# of nodes)",
                    width=width,
                )
                fff.write(
                    "{:6d}",
                    len(used_line_types),
                    description="NELTYP (# of different element types)",
                    width=width,
                )
                fff.write(
                    "{:6d}",
                    line.num_segments,
                    description="NSEG   (# of segments)",
                    width=width,
                )
                fff.write(
                    "{:6d}",
                    3,
                    description="NDIM   (# of dimensions - 2 or 3)",
                    width=width,
                )
                fff.write(
                    "{:6d}",
                    self.system.run.job_number,
                    description="JOB    (0 = pre-static, 1 = static, 2 = dynamic, 3 = dynamic/iter)",
                    width=width,
                )
                fff.write(
                    "{:6d}",
                    line.results.snapshot_frequency,
                    description="JSNAP  (snapshot each JSNAP iterations)",
                    width=width,
                )
                fff.write(
                    "{:6d}",
                    self.system.run.job_motion,
                    description="JMOTN  (1 = sinusoidal, 2 = forced, 3 = coupled)",
                    width=width,
                )
                fff.write(
                    "{:6d}",
                    2,
                    description="NCNSTR (# of constrained nodes)",
                    width=width,
                )
                fff.write(
                    "{:6d}",
                    len(line.results.output_nodes),
                    description="NRSLT  (# of nodes for time history output)",
                    width=width,
                )
                fff.write()
                fff.write("${}", self.system.parameter.output_filename)
                fff.write()
                fff.write()
                fff.write("II. Element and Nodal Information")
                fff.write()
                fff.write("$sections.dat")
                fff.write()
                fff.write("b. Coordinates and Lambdas for Each Node")

                # Connections between Nodes
                fff.write()
                fff.write("c. Connections between Nodes")
                fff.write()
                for i, segment in enumerate(line.segments):
                    fff.write(
                        "{:12.5f}" + "{:6d}" * 3,
                        segment.length,
                        used_line_types.index(segment.section_type) + 1,
                        sum(num_elements[:i]) + 1,
                        sum(num_elements[: i + 1]) + 1,
                        description="segment length & type, 1st & 2nd nodes",
                        width=34,
                    )

                # Write nodal Constraints
                fff.write()
                fff.write()
                fff.write("III. Nodal Constraints")

                for node_number in [1, sum(num_elements) + 1]:
                    node_motion_freq = 0.0
                    x_amp = 0.0
                    y_amp = 0.0
                    z_amp = 0.0
                    mass = 0.0
                    if node_number == 1:
                        node_coords = line.top_coordinates
                        initial_force = line.pretension

                    else:
                        node_coords = line.bottom_coordinates
                        initial_force = 0.0

                    fff.write()
                    fff.write("Node No.{:6d}".format(node_number))
                    fff.write()
                    fff.write("a. Linear Constraints")
                    fff.write("            direction cosines           reference")
                    fff.write("   reference   1st perp.   2nd perp.    position")
                    fff.write(
                        "{:12.5f}" * 4,
                        1,
                        0,
                        0,
                        node_coords[0],
                        description="x direction",
                        width=52,
                    )
                    fff.write(
                        "{:12.5f}" * 4,
                        0,
                        1,
                        0,
                        node_coords[1],
                        description="y direction",
                        width=52,
                    )
                    fff.write(
                        "{:12.5f}" * 4,
                        0,
                        0,
                        1,
                        node_coords[2],
                        description="z direction",
                        width=52,
                    )
                    fff.write(
                        "{0:12.5E}" * 3, 1e11, description="spring constant", width=52
                    )
                    fff.write(
                        "{0:12.5f}" * 3, 0, description="damping constant", width=52
                    )
                    fff.write(
                        "{:12.5E}" * 3,
                        initial_force,
                        0,
                        0,
                        description="initial force",
                        width=52,
                    )
                    fff.write(
                        "{:12.5f}", mass, description="concentrated mass", width=52
                    )
                    fff.write()
                    fff.write("b. Motion of Reference Point at Node{:3d}", node_number)
                    fff.write()
                    fff.write(
                        "{:12.5f}",
                        node_motion_freq,
                        description="motion frequency (rad/sec)",
                        width=30,
                    )
                    fff.write()
                    fff.write("  in-phase out-phase")
                    fff.write(
                        "{:12.5f}" * 2,
                        x_amp,
                        0,
                        description="x displacement amplitude",
                        width=30,
                    )
                    fff.write(
                        "{:12.5f}" * 2,
                        y_amp,
                        0,
                        description="y displacement amplitude",
                        width=30,
                    )
                    fff.write(
                        "{:12.5f}" * 2,
                        z_amp,
                        0,
                        description="z displacement amplitude",
                        width=30,
                    )

                # Environment Data
                fff.write()
                fff.write()
                fff.write("IV. Environmental Data")
                fff.write()
                fff.write("${}", self.environment.current_filename)
                fff.write()
                fff.write("${}", self.environment.wave_filename)
                fff.write()
                fff.write()
                fff.write("V. Dynamic Results")
                fff.write()
                fff.write("a. Output Frequency")
                fff.write()
                fff.write("{:3d}", line.results.nodal_output_frequency)
                fff.write()
                fff.write("b. Nodal Results")
                fff.write()
                for result_node in line.results.output_nodes:
                    fff.write(
                        "{:3d}" + " {:2d}" * 7,
                        result_node,
                        line.results.write_displacement,
                        line.results.write_slope,
                        line.results.write_velocity,
                        line.results.write_angular_velocity,
                        line.results.write_tension,
                        line.results.write_bending_moment,
                        line.results.write_shear_force,
                        description="r,r',r-dot,r'-dot,tension,moment,shear",
                        width=37,
                    )
                fff.write()
                fff.write("c. Global Results")
                fff.write()
                fff.write(
                    "{:3d}",
                    line.results.write_current_force,
                    description="drag force",
                    width=37,
                )

    def _write_line_types(self, line_types, case_dir):
        """Write the section type properties."""
        filename = os.path.join(case_dir, "sections.dat")
        with OutputFile(filename) as fff:
            fff.write("a. Physical Properties for Each Element Type")

            width = 41
            for i, line_type in enumerate(line_types):
                fff.write()
                fff.write(
                    "{:12.5e} {:d}",
                    line_type.youngs_modulus,
                    line_type.element_type,
                    description="Young's mod: type{:3d} ({})".format(
                        i + 1, line_type.name
                    ),
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.moment_of_inertia,
                    description="moment of inertia (I)",
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.cross_sectional_area,
                    description="cross-section area (Af)",
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.internal_cavity_area,
                    description="internal cavity area (Ai)",
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.outer_fiber_distance,
                    description="dist. to outermost fiber",
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.mass_per_unit_length,
                    description="mass per unit length",
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.hydrodynamic_diameter,
                    description="hydrodynamic diameters",
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.normal_drag_coefficient,
                    description="normal drag coefficient",
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.axial_drag_coefficient,
                    description="tangential drag coefficient",
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.added_mass_coefficient,
                    description="added-mass coefficient",
                    width=width,
                )
                fff.write(
                    "{0:12.5e}" * 3,
                    line_type.buoyant_force_per_unit_length,
                    description="total buoyancy/unit length",
                    width=width,
                )

    def _write_system_file(self, case_dir):

        # Write the data to the input file
        filename = os.path.join(case_dir, self.system.output_filename)
        with OutputFile(filename) as fff:
            # Write Header Code
            fff.write(self.system.description)
            fff.write()
            fff.write("I. System Indexs")
            fff.write()
            fff.write("# of mooring lines, NLINE   = {:6d}", len(self.system.lines))
            fff.write("# of dimensions, 2 or 3     = {:6d}", 3)
            fff.write(
                "x, y and z of ref. point    = " + "{:12.5f}" * 3,
                *self.system.reference_location,
            )
            fff.write(
                "init. displ. of ref. point  = " + "{:12.5f}" * 3,
                *self.system.initial_displacement,
            )
            fff.write(" " * 30 + "{:12.5f}" * 3, *self.system.initial_rotation)
            fff.write(
                "unit, file for ten. at c.g. = {:6d} {}",
                38,
                self.system.filename.cg_tension,
            )
            fff.write(
                "unit, file for con. results = {:6d} {}",
                39,
                self.system.filename.results,
            )
            fff.write()
            fff.write()
            fff.write("II. Line File Names")
            for i, line in enumerate(self.system.lines):
                fff.write()
                fff.write("{:<27s} = {:6d} {}.inp", "1. input file", 40, line.name)
                fff.write("{:<27s} = {:6d} {}.out", "2. output file", 41, line.name)
                fff.write(
                    "{:<27s} = {:6d} {}_snap.out", "3. snapshot file", 0, line.name
                )
                fff.write(
                    "{:<27s} = {:6d} {}_fdmtn.out",
                    "4. forced motion file",
                    0,
                    line.name,
                )
                fff.write(
                    "{:<27s} = {:6d} {}_tmhis.out",
                    "5. time history file",
                    50 + i,
                    line.name,
                )

    def _write_numerical_parameters(self, case_dir):
        param = self.system.parameter

        # Write the parameter data to the input file
        filename = os.path.join(case_dir, param.output_filename)
        width = 39
        with OutputFile(filename) as fff:
            # Write Header Code
            fff.write("b. Parameters")
            fff.write()
            fff.write(
                "{:12.5f}" * 3,
                param.relaxation,
                param.structural_damping,
                param.ramping_constant,
                description="relaxation, damping & ramping constant",
                width=width,
            )
            fff.write(
                "{:12.5f}" * 2,
                param.beta,
                param.gamma,
                description="beta and gamma",
                width=width,
            )
            fff.write(
                "{:12.5e}{:6d}",
                param.tolerance,
                param.max_iterations,
                description="iteration accuracy, # iterations",
                width=width,
            )
            fff.write(
                "{:12.5f}" * 3,
                param.start_time,
                param.end_time,
                param.time_step,
                description="begin time, end time & time step",
                width=width,
            )
            fff.write(
                "{:12.5f}" * 3,
                param.water_density,
                param.contents_density,
                param.gravity,
                description="mass density of water, fluid; gravity",
                width=width,
            )
            fff.write(
                "{:12.5f}", -param.water_depth, description="bottom depth", width=width
            )


class OutputFile(object):
    """A file-like object to handle writing to a file with a specific format."""

    def __init__(self, name):
        self.name = name
        self._file = open(name, "w")

    def __enter__(self):
        return self

    def __exit__(self, type_, value, traceback):
        self._file.close()
        return isinstance(value, TypeError)

    def write(self, value_str="", *values, description="", width=0):
        """Write a value string to the file, plus a description."""
        string = "{0:<{1}s}{2}\n".format(value_str.format(*values), width, description)
        try:
            self._file.write(string)
        except Exception as ex:
            print(ex)
            raise
