import click
import click_log

from . import logger
from seamoor.model import Model

click_log.basic_config(logger)


class Option(object):
    """Descriptor to decoration of multiple sub-commands. Accepts same arguments as click.option."""

    def __init__(self, *parameter_names, **kwargs):
        self.name = None
        self.parameter_names = parameter_names
        self.kwargs = kwargs

    def __set_name__(self, _, name):
        self.name = name

    def __set__(self, instance, value):
        instance.__dict__[self.name] = value

    def __get__(self, instance, _):
        return instance.__dict__[self.name]

    def decorator(self, f):
        def callback(ctx, _, value):
            state = ctx.ensure_object(State)
            setattr(state, self.name, value)
            return value

        return click.option(
            *self.parameter_names, callback=callback, expose_value=False, **self.kwargs
        )(f)


class State(object):
    """Stored state to allow shared options for different sub-commands."""

    pre_static = Option("--pre-static", is_flag=True)
    static = Option("--static", is_flag=True)
    harmonic = Option("--harmonic", is_flag=True)
    dynamic = Option("--dynamic", is_flag=True)
    implicit = Option("--implicit", is_flag=True)
    explicit = Option("--explicit", is_flag=True)
    case_dir = Option("--case-dir", default=".")


pass_state = click.make_pass_decorator(State, ensure=True)


def common_options(f):
    """Apply multiple decorators to sub-commands."""
    for option in State.__dict__.values():
        if isinstance(option, Option):
            f = option.decorator(f)
    f = click_log.simple_verbosity_option(logger)(f)
    f = pass_state(f)
    return f


def make_model(state):
    model = Model()
    return model


@click.group()
def cli():
    pass


@cli.command(help="Write the Cable3d input files and run the program")
@common_options
def run(state):
    model = make_model(state)
    model.write(state.case_dir)
    if state.pre_static:
        model.run_pre_statics(state.case_dir)


@cli.command(help="Write the Cable3d input files")
@common_options
def write(state):
    model = make_model(state)
    model.write(state.case_dir)
    return model


if __name__ == "__main__":
    cli()
